package com.josep.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Data
@Entity
@Table(name="ships")
public class Barco {
	
	@Id
	@GeneratedValue( strategy=GenerationType.IDENTITY)
	private long id;

	@Column(name="launched")
	private int anyLlançat;
	
	@ManyToMany(cascade = {CascadeType.ALL}, mappedBy="ListaBarcos")
	
	@ToString.Exclude
	private List<Batalla> ListaBatallas= new ArrayList<Batalla>();
	
	
}
