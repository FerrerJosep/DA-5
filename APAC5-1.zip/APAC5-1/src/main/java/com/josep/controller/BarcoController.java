package com.josep.controller;

public class BarcoController {

}
