package com.josep.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BatallaController {
	
	@GetMapping("/")
	public String index() {
		myLog.info(context.getMethod() + " from " + context.getRemoteHost());
        return "Welcome to " + nombreAplicacion + " de " + nombreAsignatura;
	}
	

}
