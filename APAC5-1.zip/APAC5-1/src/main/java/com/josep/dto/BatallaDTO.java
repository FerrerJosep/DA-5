package com.josep.dto;

import java.io.Serializable;
import com.josep.model.Batalla;
import lombok.Data;



@Data
public class BatallaDTO implements Serializable{

	private static final long serialVersionUID=1L;
	private long idBatalla;
	private String diaLlançat;
	private BarcoDTO barcodto;
	
	
	public static BatallaDTO convertToDTO(Batalla batalla, BarcoDTO barco) {
		
		BatallaDTO batallaDTO= new BatallaDTO();
		batallaDTO.setIdBatalla(batalla.getId());
		batallaDTO.setDiaLlançat(batalla.getDiaLlançat());
		batallaDTO.setBarcodto(barco);
		
		
		return batallaDTO;
		
	}
	
	public static Batalla ConvertToEntity(BatallaDTO batalladto) {
		
		
		Batalla batalla= new Batalla();
		batalla.setId(batalladto.getIdBatalla());
		batalla.setDiaLlançat(batalladto.getDiaLlançat());
		
		
		
		return batalla;
		
	}
}
