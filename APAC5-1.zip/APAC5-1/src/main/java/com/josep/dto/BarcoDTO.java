package com.josep.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


import com.josep.model.Barco;
import com.josep.model.Batalla;
import com.josep.dto.BatallaDTO;


import lombok.Data;

@Data
public class BarcoDTO implements Serializable{
	
	private static final long serialVersionUID= 1L;
	
	private Long idBarco;
	private int anyLLançat ; 
	

	
	// Convierte una entidad a un objeto DTO con todos los datos
		public static BarcoDTO convertToDTO(Barco barco) {
			// Creamos el clienteDTO y asignamos los valores basicos
			BarcoDTO barcoDTO = new BarcoDTO();
			
			barcoDTO.setIdBarco(barco.getId());
			
			barcoDTO.setAnyLLançat(barco.getAnyLlançat());
			   
			
			for (Batalla laBatalla:barco.getListaBatallas()) {
				BatallaDTO batalladto = BatallaDTO.convertToDTO(laBatalla, barcoDTO);
				barcoDTO.getListaBatallas().add(batalladto);
			}
			
			
			
			return barcoDTO;
		}
	
	

	



	public static Barco convertToEntity(BarcoDTO barcodto) {
		Barco barco= new Barco();
		barco.setId(barcodto.getIdBarco());
		barco.setAnyLlançat(barcodto.getAnyLLançat());
		
		
		
		
		return barco;
		
	}
	

}
