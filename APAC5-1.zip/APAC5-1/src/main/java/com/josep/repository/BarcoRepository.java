package com.josep.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.josep.model.Barco;
import java.util.List;


@Repository
@Transactional
public interface BarcoRepository extends JpaRepository<Barco, Long>{
	
	List<Barco> findById(String id);


}
