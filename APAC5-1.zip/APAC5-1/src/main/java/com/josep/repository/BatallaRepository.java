package com.josep.repository;

public class BatallaRepository {

}
