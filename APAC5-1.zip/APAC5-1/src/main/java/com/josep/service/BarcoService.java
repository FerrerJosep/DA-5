package com.josep.service;

import java.util.List;

import javax.transaction.Transactional;

import com.josep.dto.BarcoDTO;

@Transactional
public interface BarcoService {

	
	BarcoDTO saveBarco(BarcoDTO barcoDTO);
	BarcoDTO getBarcoById(Long id);
	List<BarcoDTO> listAllBarcos();
	void deleteBarco(Long id);
	
}
