package com.josep.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.josep.dto.BarcoDTO;
import com.josep.model.Barco;
import com.josep.repository.BarcoRepository;

// import com.josep.repository.ClienteRepository;

import jdk.internal.org.objectweb.asm.tree.IntInsnNode;


@Service
public class BarcoServiceImpl implements BarcoService {
	
	@Autowired
	private BarcoRepository barcoRepository;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public BarcoDTO saveBarco(BarcoDTO barcoDTO) {
		Barco barco = BarcoDTO.convertToEntity(barcoDTO);
		Barco newBarco=barcoRepository.save(barco);
		return BarcoDTO.convertToDTO(newBarco);
	}

	@Override
	public BarcoDTO getBarcoById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BarcoDTO> listAllBarcos() {
		List<Barco> lista = barcoRepository.findAll();
		List<BarcoDTO> listaResultado = new ArrayList<BarcoDTO>();
		for (int i = 0; i < lista.size(); ++i) {
		    listaResultado.add(BarcoDTO.convertToDTO(lista.get(i)));
		}
		return listaResultado;
	}

	@Override
	public void deleteBarco(Long id) {
		barcoRepository.deleteById(id);
		
	}

}
